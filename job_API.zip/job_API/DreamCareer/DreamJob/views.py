from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import JobListing
from .serializers import JobListingSerializer

class DreamJobView(APIView):  # Changed from 'JobListingView' to 'DreamJobView'
    def get(self, request):
        job_listings = JobListing.objects.all()
        serializer = JobListingSerializer(job_listings, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = JobListingSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
