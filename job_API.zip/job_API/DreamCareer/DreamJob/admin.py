from django.contrib import admin
from .models import JobListing

admin.site.register(JobListing)
